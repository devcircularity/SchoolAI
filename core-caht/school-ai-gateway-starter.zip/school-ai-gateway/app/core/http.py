import httpx
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_exception_type
from app.core.config import settings

class CoreHTTP:
    def __init__(self):
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(
            connect=settings.HTTP_CONNECT_TIMEOUT,
            read=settings.HTTP_READ_TIMEOUT,
        ))

    async def close(self):
        await self._client.aclose()

    def headers(self, bearer: str | None, school_id: str | None, idem_key: str | None):
        h = {}
        if bearer:
            if not bearer.lower().startswith("bearer "):
                h["Authorization"] = f"Bearer {bearer}"
            else:
                h["Authorization"] = bearer
        if school_id:
            h["X-School-ID"] = school_id
        if settings.SERVICE_TOKEN:
            h["X-Service-Auth"] = settings.SERVICE_TOKEN
        if idem_key:
            h["Idempotency-Key"] = idem_key
        return h

    @retry(stop=stop_after_attempt(settings.RETRY_ATTEMPTS), wait=wait_fixed(0.4),
           retry=retry_if_exception_type(httpx.HTTPError))
    async def get(self, path: str, bearer: str | None, school_id: str | None):
        url = settings.CORE_API_BASE + path
        return await self._client.get(url, headers=self.headers(bearer, school_id, None))

    async def post(self, path: str, bearer: str | None, school_id: str | None, data: dict, idem_key: str | None):
        url = settings.CORE_API_BASE + path
        return await self._client.post(url, json=data, headers=self.headers(bearer, school_id, idem_key))

    async def patch(self, path: str, bearer: str | None, school_id: str | None, data: dict, idem_key: str | None):
        url = settings.CORE_API_BASE + path
        return await self._client.patch(url, json=data, headers=self.headers(bearer, school_id, idem_key))
