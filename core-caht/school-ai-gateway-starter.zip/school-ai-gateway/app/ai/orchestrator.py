from typing import Dict, Any
from app.ai.intents import detect_intent, extract_slots, missing_slots
from app.ai.llm import OllamaClient
from app.ai import prompt_templates as T
from app.state.memory import get_state, set_state, clear_state
from app.core.http import CoreHTTP
from app.ai.tools.base import ToolContext
from app.ai.tools import create_class as tool_create_class
from app.ai.tools import enroll_student as tool_enroll_student
from app.ai.tools import send_notification as tool_send_notification
from app.ai.tools import modify_fee as tool_modify_fee

class Orchestrator:
    def __init__(self):
        self.llm = OllamaClient()
        self.http = CoreHTTP()

    async def run_chat_turn(self, *, session_id: str, message: str, bearer: str, school_id: str, message_id: str | None) -> Dict[str, Any]:
        state = await get_state(session_id) or {}
        intent = state.get("intent") or detect_intent(message)
        slots = dict(state.get("slots", {}))
        if intent:
            slots.update(extract_slots(intent, message))

        if not intent:
            content = await self.llm.generate(T.SYSTEM_PROMPT, [{"role":"user","content": message}])
            return {"content": content}

        miss = missing_slots(intent, slots)
        if miss:
            await set_state(session_id, {"intent": intent, "slots": slots})
            numbered = "\n".join([f"{i+1}) {m}" for i,m in enumerate(miss)])
            return {"content": f"I need the missing fields:\n{numbered}"}

        ctx = ToolContext(self.http, school_id, bearer, message_id)

        if intent == "create_class":
            res = await tool_create_class.run(ctx, {
                "name": slots["name"],
                "level": slots["level"],
                "academic_year": slots["academic_year"],
                **({"stream": slots.get("stream")} if slots.get("stream") else {})
            })
            await clear_state(session_id)
            return {"content": "Class created.", "tool": intent, "result": res}

        if intent == "enroll_student":
            res = await tool_enroll_student.run(ctx, slots)
            await clear_state(session_id)
            return {"content": "Student enrolled.", "tool": intent, "result": res}

        if intent == "send_notification":
            res = await tool_send_notification.run(ctx, {
                "type": slots["type"],
                "subject": slots["subject"],
                "body": slots["body"],
                "target": slots["target"],
            })
            await clear_state(session_id)
            return {"content": "Notification sent.", "tool": intent, "result": res}

        if intent == "modify_fee":
            if not slots.get("_confirmed"):
                prev = await tool_modify_fee.preview(ctx, slots["term"], slots["year"], slots["items"])
                await set_state(session_id, {"intent": intent, "slots": {**slots, "_preview": prev}})
                return {"content": "Preview ready. Confirm to apply? (yes/no)", "tool": "modify_fee.preview", "result": prev}
            else:
                prev = slots.get("_preview", {})
                body = prev.get("body", {})
                sid = body.get("diff", {}).get("structure_id") or body.get("target", {}).get("id")
                changes = body.get("diff", {}).get("changes") or slots.get("items", [])
                if not sid:
                    return {"content": "No structure selected to modify."}
                res = await tool_modify_fee.apply(ctx, sid, changes)
                await clear_state(session_id)
                return {"content": "Fee structure updated.", "tool": intent, "result": res}

        content = await self.llm.generate(T.SYSTEM_PROMPT, [{"role":"user","content": message}])
        return {"content": content}
