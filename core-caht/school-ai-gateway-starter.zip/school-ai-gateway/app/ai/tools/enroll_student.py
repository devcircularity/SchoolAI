from app.ai.tools.base import ToolContext, ToolResult

async def resolve_class_id(ctx: ToolContext, class_name: str) -> str | None:
    r = await ctx.http.get(f"/api/v1/classes?search={class_name}", ctx.bearer, ctx.school_id)
    if r.status_code != 200:
        return None
    data = r.json()
    if isinstance(data, list) and len(data) == 1:
        return data[0]["id"]
    return None

async def run(ctx: ToolContext, payload: dict) -> ToolResult:
    p1 = {k: payload.get(k) for k in ["admission_no", "first_name", "last_name", "gender"] if payload.get(k) is not None}
    r1 = await ctx.http.post("/api/v1/students", ctx.bearer, ctx.school_id, p1, ctx.message_id)
    if r1.status_code not in (200, 201):
        return {"status": r1.status_code, "body": r1.json() if r1.content else None}

    student = r1.json()
    class_id = payload.get("class_id")
    if not class_id and payload.get("class_name"):
        class_id = await resolve_class_id(ctx, payload["class_name"])
    if not class_id:
        return {"status": 400, "body": {"detail": "Class not found or ambiguous"}}
    r2 = await ctx.http.patch(f"/api/v1/students/{student['id']}", ctx.bearer, ctx.school_id, {"class_id": class_id}, ctx.message_id)
    return {"status": r2.status_code, "body": r2.json() if r2.content else None}
