from app.ai.tools.base import ToolContext, ToolResult

async def run(ctx: ToolContext, payload: dict) -> ToolResult:
    resp = await ctx.http.post("/api/v1/classes", ctx.bearer, ctx.school_id, payload, ctx.message_id)
    return {"status": resp.status_code, "body": resp.json() if resp.content else None}
