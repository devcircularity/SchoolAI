import httpx
from app.core.config import settings

class OllamaClient:
    def __init__(self):
        self._client = httpx.AsyncClient(timeout=30)

    async def generate(self, system: str, messages: list[dict], json_mode: bool=False):
        payload = {
            "model": settings.OLLAMA_MODEL,
            "messages": [{"role": "system", "content": system}] + messages,
            "stream": False,
        }
        if json_mode:
            payload["format"] = "json"
        r = await self._client.post(f"{settings.OLLAMA_BASE_URL}/v1/chat/completions", json=payload)
        r.raise_for_status()
        data = r.json()
        return data["choices"][0]["message"]["content"]

    async def close(self):
        await self._client.aclose()
