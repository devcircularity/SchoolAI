import re
from typing import Dict, Any, Optional

CREATE_CLASS_PAT = re.compile(r"\b(create|new|add)\s+(class|grade)\b", re.I)
ENROLL_PAT = re.compile(r"\b(enroll|admit|register)\b.+\b(student)\b", re.I)
NOTIFY_PAT = re.compile(r"\b(notify|send|message)\b", re.I)
FEE_PAT = re.compile(r"\b(increase|decrease|add|remove)\b.+\b(fee|tuition|structure)\b", re.I)

def detect_intent(text: str) -> Optional[str]:
    if CREATE_CLASS_PAT.search(text): return "create_class"
    if ENROLL_PAT.search(text): return "enroll_student"
    if NOTIFY_PAT.search(text): return "send_notification"
    if FEE_PAT.search(text): return "modify_fee"
    return None

def extract_slots(intent: str, text: str) -> Dict[str, Any]:
    slots: Dict[str, Any] = {}
    t = text.strip()

    if intent == "create_class":
        m = re.search(r"(grade\s*\d+[^,]*)", t, re.I)
        if m:
            slots["name"] = m.group(1).title().strip()
            lvl = re.search(r"grade\s*(\d+)", slots["name"], re.I)
            if lvl: slots["level"] = f"Grade {lvl.group(1)}"
        y = re.search(r"(?:for|year)\s*(20\d{2})", t, re.I)
        if y: slots["academic_year"] = int(y.group(1))
        stream = re.search(r"\b(west|east|north|south|a|b|c)\b", t, re.I)
        if stream: slots["stream"] = stream.group(1).title()

    elif intent == "enroll_student":
        m = re.search(r"enroll\s+(?:a\s+student\s+)?([A-Za-z'-]+)\s+([A-Za-z'-]+)", t, re.I)
        if m:
            slots["first_name"] = m.group(1).title()
            slots["last_name"] = m.group(2).title()
        g = re.search(r"\b(male|female)\b", t, re.I)
        if g: slots["gender"] = g.group(1).title()
        cn = re.search(r"class\s*([A-Za-z0-9\s-]+)", t, re.I)
        if cn: slots["class_name"] = cn.group(1).strip().title()

    elif intent == "send_notification":
        if re.search(r"\bdebtor(s)?\b", t, re.I):
            slots["target"] = {"all_debtors": True}
        body = re.search(r"['\"](.+?)['\"]", t)
        if body: slots["body"] = body.group(1)
        if "email" in t.lower():
            slots["type"] = "EMAIL"
        else:
            slots["type"] = "IN_APP"
        if "fees" in t.lower():
            slots["subject"] = "Fees Reminder"

    elif intent == "modify_fee":
        op = re.search(r"\b(increase|decrease|add|remove)\b", t, re.I)
        if op: slots["operation"] = op.group(1).lower()
        term = re.search(r"term\s*(\d)", t, re.I)
        if term: slots["term"] = int(term.group(1))
        year = re.search(r"(20\d{2})", t)
        if year: slots["year"] = int(year.group(1))
        amt = re.search(r"(?:(?:by)|amount)\s*([0-9][0-9,]*)", t, re.I)
        if amt:
            slots.setdefault("items", [])
            slots["items"].append({"name": "Tuition", "amount": int(amt.group(1).replace(',', ''))})

    return slots

REQUIRED_SLOTS = {
    "create_class": ["name", "level", "academic_year"],
    "enroll_student": ["first_name", "last_name", "gender", ["class_id","class_name"]],
    "send_notification": ["type", "subject", "body", "target"],
    "modify_fee": [["structure_id", ("term","year")], "operation", "items"]
}

def missing_slots(intent: str, slots: Dict[str, Any]) -> list:
    missing = []
    reqs = REQUIRED_SLOTS.get(intent, [])
    for r in reqs:
        if isinstance(r, (list, tuple)):
            if not any((k in slots and slots[k]) for k in r):
                missing.append(f"one of: {', '.join(map(str, r))}")
        else:
            if r not in slots or slots[r] in (None, "", []):
                missing.append(r)
    return missing
