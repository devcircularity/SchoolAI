from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List
from uuid import uuid4
from datetime import datetime, timezone
from app.deps.auth import get_auth_ctx, AuthContext
from app.deps.tenant import get_school_id
from app.state.memory import get_state, set_state, clear_state
from app.ai.orchestrator import Orchestrator
from app.core.http import CoreHTTP

router = APIRouter(prefix="/ai")

CHATS = {}
MESSAGES = {}

class ChatCreate(BaseModel):
    title: Optional[str] = None

class Chat(BaseModel):
    id: str
    title: str
    created_at: str
    system_facts_seeded: bool

class MessageCreate(BaseModel):
    content: str
    message_id: Optional[str] = None

class Message(BaseModel):
    id: str
    role: str
    content: str
    created_at: str

@router.post("/chats", response_model=Chat)
async def create_chat(body: ChatCreate, ctx: AuthContext = Depends(get_auth_ctx), school_id: str = Depends(get_school_id)):
    chat_id = str(uuid4())
    title = body.title or "New Chat"
    CHATS[chat_id] = {"id": chat_id, "title": title, "created_at": datetime.now(timezone.utc).isoformat()}
    MESSAGES[chat_id] = []

    http = CoreHTTP()
    try:
        r = await http.get("/api/v1/schools/my", bearer=ctx.raw_bearer, school_id=school_id)
        seeded = r.status_code == 200
    except Exception:
        seeded = False

    return Chat(id=chat_id, title=title, created_at=CHATS[chat_id]["created_at"], system_facts_seeded=seeded)

@router.get("/chats/{chat_id}/messages", response_model=List[Message])
async def list_messages(chat_id: str, before_id: Optional[str] = Query(None)):
    return MESSAGES.get(chat_id, [])

_orch = Orchestrator()

@router.post("/chats/{chat_id}/messages")
async def post_message(chat_id: str, body: MessageCreate, ctx: AuthContext = Depends(get_auth_ctx), school_id: str = Depends(get_school_id)):
    if chat_id not in CHATS:
        raise HTTPException(status_code=404, detail="Chat not found")

    mid = body.message_id or str(uuid4())
    user_msg = {"id": mid, "role": "user", "content": body.content, "created_at": datetime.now(timezone.utc).isoformat()}
    MESSAGES[chat_id].append(user_msg)

    lower = body.content.strip().lower()
    state = await get_state(chat_id)
    if state and state.get("intent") == "modify_fee" and "_confirmed" not in state.get("slots", {}):
        if lower in ("yes", "y"):
            state["slots"]["_confirmed"] = True
            await set_state(chat_id, state)
        elif lower in ("no", "n"):
            await clear_state(chat_id)
            assistant = {"id": str(uuid4()), "role": "assistant", "content": "Cancelled.", "created_at": datetime.now(timezone.utc).isoformat()}
            MESSAGES[chat_id].append(assistant)
            return {"assistant": assistant}

    result = await _orch.run_chat_turn(session_id=chat_id, message=body.content, bearer=ctx.raw_bearer, school_id=school_id, message_id=mid)

    assistant = {
        "id": str(uuid4()),
        "role": "assistant",
        "content": result.get("content", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tool_call": result.get("tool"),
        "tool_result": result.get("result"),
    }
    MESSAGES[chat_id].append(assistant)
    return {"assistant": assistant}
